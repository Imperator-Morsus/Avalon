# Avalon Project Tree

Clean source tree excluding generated artifacts (`target/`, `node_modules/`, `logs/`, `__pycache__/`, lock files, and log files).

```
Avalon/
├── Cargo.toml
├── launch.py
├── LICENSE
├── README.md
│
├── .env.example
├── .avalon_fs.json
├── .avalon_fs.json.example
├── .avalon_state.json
├── .gitattributes
├── .gitignore
│
├── client/
│   ├── main.js
│   ├── preload.js
│   ├── package.json
│   ├── README.md
│   │
│   ├── api/
│   │   └── ApiService.js
│   │
│   ├── contracts/
│   │   └── InferenceContract.js
│   │
│   └── ui/
│       ├── index.html
│       ├── style.css
│       └── app.js
│
├── src/
│   ├── main.rs
│   ├── fs.rs
│   ├── mindmap.rs
│   │
│   └── tools/
│       ├── mod.rs
│       ├── fs_tools.rs
│       ├── config_tool.rs
│       ├── mindmap_tool.rs
│       ├── fetch_tool.rs
│       ├── remote_mindmap_tool.rs
│       └── web_scrape_tool.rs
│
└── Docs/
    ├── ARCHITECTURE_SPEC.md
    ├── CAPABILITIES.md
    ├── CHANGELOG.md
    ├── CONTINGENCY.md
    ├── INSTALL.md
    ├── README.md
    ├── SECURITY_PROTOCOL.md
    └── Avalon-Tree.md
```

---

## Generated / Ignored Directories

These are created at runtime and excluded from the tree above:

| Directory | Contents | Created By |
|-----------|----------|------------|
| `target/` | Rust build artifacts (`cargo`) | `cargo build` |
| `node_modules/` | npm packages | `npm install` (in `client/`) |
| `logs/` | Debug log Markdown files | Runtime (`/api/debug/save`) |
| `__pycache__/` | Python bytecode | Python runtime |
