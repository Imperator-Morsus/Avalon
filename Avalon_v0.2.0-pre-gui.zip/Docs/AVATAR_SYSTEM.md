# Avalon Avatar System Design

**Document Status:** Design Specification  
**Last Updated:** 2026-04-29  
**Scope:** Two-tier avatar architecture for the Avalon AI harness

---

## Overview

Avalon supports two distinct avatar concepts:

1. **Ambient Avatar (UI-Reactive)** — A visual presence that reflects the harness state. Zero tool exposure. Purely decorative/ambient.
2. **Agentic Avatar (Model-Controlled)** — A virtual interface that the AI model directly manipulates via tools to express emotion, gesture, speak, and present visual information.

Both can coexist. This document specifies each architecture.

---

## Part 1: Ambient Avatar (UI-Reactive)

### Purpose
Provide the user with an at-a-glance visual indicator of what the harness is doing. No model agency involved.

### State Machine
The avatar reacts to four harness states:

| State | Visual | Trigger |
|-------|--------|---------|
| `idle` | Neutral expression, slow blink | Ready, waiting for input |
| `thinking` | Squinted eyes, breathing glow | SSE connected, awaiting first token |
| `speaking` | Open mouth, head bob | Text tokens streaming |
| `error` | X-eyes, O-mouth, red border | SSE dropped or backend error |

### Implementation
- **Renderer:** CSS/SVG (no external dependencies)
- **Hook:** `setStatus(type, text)` in `client/ui/app.js`
- **Cost:** ~2KB CSS, zero runtime overhead

### Extension Points
- Swap the SVG face for a pixel-art sprite sheet (CSS `background-position` animation)
- Replace with a `<canvas>` particle orb that changes color by state
- Plug in a WebGL Three.js head that rotates toward the input area when `speaking`

---

## Part 2: Agentic Avatar (Model-Controlled)

### Purpose
Give the AI a persistent virtual body it can consciously direct. The avatar becomes an output channel on par with text, tool calls, and file writes.

### Core Concepts

#### Avatar State (Backend)
Stored in the backend as a JSON state object:

```json
{
  "expression": "neutral",
  "gesture": null,
  "speech_viseme": "sil",
  "gaze_target": [0.5, 0.5],
  "screen_position": [0.85, 0.20],
  "zoom": 1.0,
  "overlay_text": null,
  "mood_score": { "joy": 0.0, "anger": 0.0, "sadness": 0.0, "surprise": 0.0 }
}
```

#### Control Interface (Tool)
A new core tool `control_avatar` exposed to the model:

```json
{
  "tool": "control_avatar",
  "input": {
    "action": "set_expression",
    "value": "curious",
    "duration_ms": 2000,
    "transition": "smooth"
  }
}
```

Supported actions:

| Action | Parameters | Description |
|--------|------------|-------------|
| `set_expression` | `value`, `duration_ms`, `transition` | Face mood: `neutral`, `happy`, `sad`, `angry`, `surprised`, `curious`, `concerned`, `asleep` |
| `set_gesture` | `value`, `strength` (0.0-1.0) | Body gesture: `wave`, `nod`, `shake_head`, `shrug`, `point`, `thumbs_up`, `facepalm` |
| `look_at` | `target_x` (0-1), `target_y` (0-1) | Direct gaze to a screen coordinate |
| `speak_viseme` | `viseme` | Lip-sync frame: `aa`, `ih`, `oh`, `uu`, `ee`, `sil`, `th`, `ff` |
| `move_to` | `position_x` (0-1), `position_y` (0-1), `duration_ms` | Reposition on screen |
| `show_overlay` | `text`, `duration_ms` | Floating speech/thought bubble |
| `clear_overlay` | — | Remove bubble |

#### Rendering Layer (Frontend)

**Architecture:** Canvas 2D or WebGL layer sits above the chat UI at `z-index: 50`. The avatar is rendered independently of DOM layout.

**Asset Strategy (choose one):**

1. **Vector/Sprite approach**
   - Pre-drawn SVG layers for: face base, eyes, mouth, eyebrows, hands
   - CSS transforms for position/rotation
   - Fast, crisp, easy to theme
   - Good for: anime, cartoon, minimalist styles

2. **Live2D-style approach**
   - Rigged mesh with morph targets
   - Requires artist-created assets (`.moc3`, `.model3.json`)
   - Can use Cubism Web SDK (free for indie/research)
   - Good for: expressive 2D anime characters

3. **3D Model approach**
   - Three.js + glTF character
   - Bone-driven animation for gestures
   - Morph targets for expressions
   - Good for: stylized 3D, realism, VRM (VTuber) avatars

4. **Generated Image approach**
   - Model calls `create_media` to generate a portrait
   - Frontend caches and cross-fades between generated states
   - Latency: 3-15s per expression change
   - Good for: highly stylized, non-realtime, artistic avatars

### Data Flow

```
User sends message
        |
        v
Backend receives message, creates SSE stream
        |
        v
LLM generates response + optional tool calls
        |
        +---> control_avatar("set_expression", "thinking")
        +---> control_avatar("set_gesture", "nod")
        +---> control_avatar("speak_viseme", "aa")
        |
        v
Each control_avatar call pushes a JSON event over SSE
        |
        v
Frontend receives `avatar_update` SSE event
        |
        v
Canvas renderer interpolates to new state (60fps)
```

### TTS Integration (Optional but Recommended)

If Avalon adds TTS output, the avatar `speak_viseme` stream can be driven automatically:

```
TTS phoneme stream
      |
      v
Phoneme-to-viseme mapper (`phoneme_map.rs`)
      |
      v
Auto-generated `control_avatar("speak_viseme", "...")` calls
```

This frees the LLM from managing lip-sync directly. The model only sets expressions and gestures intentionally.

### Backend Implementation Plan

#### New Files
- `src/avatar.rs` — Avatar state machine, SSE event emitter
- `src/tools/avatar_tool.rs` — `control_avatar` tool implementation
- `client/ui/avatar_renderer.js` — Canvas rendering loop

#### Modifications
- `src/main.rs` — Add avatar state to AppState, wire SSE endpoint
- `src/tools/mod.rs` — Register `control_avatar` tool
- `client/ui/index.html` — Add `<canvas id="avatarCanvas">` overlay
- `client/ui/app.js` — Import avatar renderer, handle `avatar_update` SSE events

#### API Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/avatar/state` | Current avatar state JSON |
| POST | `/api/avatar/reset` | Reset to idle defaults |

#### SSE Event Type

```
event: avatar_update
data: {"expression": "happy", "gesture": "wave", "overlay_text": "Hello!"}
```

### Security Considerations

- The avatar tool should be **core** (always available to the model) or **whitelistable** per agent.
- `look_at` coordinates must be clamped to [0,1] to prevent invalid rendering.
- `overlay_text` must be HTML-escaped before rendering to prevent XSS via model-generated avatar bubbles.
- Rate-limit avatar updates to ~30/sec to prevent DoS via rapid SSE events.

### Fallback Behavior

If avatar assets fail to load or the user disables the avatar in settings:
- The `control_avatar` tool still succeeds (so the model doesn't error-loop)
- Events are silently dropped
- A config toggle `avatar_enabled: bool` controls this

---

## Decision Guide

| Factor | Ambient Only | Agentic Avatar |
|--------|-------------|----------------|
| **Complexity** | Low (1-2 files) | Medium-High (6-10 files) |
| **Asset needs** | None, or 1 sprite | Rigged model + textures |
| **Model awareness** | None | Model knows it "has a body" |
| **Latency** | Instant | 16ms render + ~50ms tool overhead |
| **User wow-factor** | Low | High |
| **Maintenance** | Near-zero | Ongoing asset pipeline |
| **Best for** | Productivity users, minimalists | Assistants, companions, streamers |

---

## Recommended Next Steps

1. **Ship Ambient Avatar first** — low risk, improves UX immediately, establishes visual identity.
2. **Add `control_avatar` tool** with a simple CSS/SVG renderer. Let the model learn it exists.
3. **Observe model behavior** — does it use the avatar naturally? Does it over-use gestures?
4. **Upgrade renderer** to Live2D or Three.js once the control interface is validated.
5. **Add TTS + auto-viseme** as a polish pass, not a dependency.

---

## References

- [Cubism SDK for Web](https://www.live2d.com/download/cubism-sdk/download-web/) — Live2D rendering
- [Three.js](https://threejs.org/) — WebGL 3D
- [VRM Specification](https://vrm.dev/) — Cross-platform 3D avatar format
- [OVRLipSync](https://developer.oculus.com/documentation/unity/unity-ovrlipsync/) / [Rhubarb Lip Sync](https://github.com/DanielSWolf/rhubarb-lip-sync) — Phoneme-to-viseme
