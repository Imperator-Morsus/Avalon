# Avalon Pragmatic Security Hardening Plan

**Document Status:** Active Implementation Target
**Last Updated:** 2026-04-29
**Goal:** Make Avalon defensible for corporate distribution without full CMMC Level 2 audit overhead.

---

## Executive Summary

This plan hardens Avalon to a level that satisfies **most corporate security questionnaires** and provides defensible security for a desktop AI coding assistant. It does **not** achieve CMMC Level 2 certification, but it closes the most critical gaps (authentication, encryption, access control, audit) that corporate IT and InfoSec teams care about.

**Scope:** Technical controls only. Organizational policies (training, physical security, personnel screening) are out of scope and must be handled by the deploying organization.

**Target audience:** Companies evaluating Avalon for internal developer use who need to answer security questionnaires but do not handle CUI or require CMMC certification.

---

## Guiding Principles

1. **Don't over-engineer.** If a control is organizational (training, background checks), document the gap rather than building software for it.
2. **Use proven libraries.** Prefer battle-tested crates over custom crypto.
3. **Default secure.** New installations should be secure without manual configuration.
4. **Audit everything.** If it touches user data or config, it gets logged.
5. **Fail closed.** If a security check errors, deny the operation.

---

## Phase 1 — Authentication & Session Management (Weeks 1–2)

### 1.1 Local User Accounts

**Why:** Without identity, there is no accountability. Corporate IT will reject any tool that is "open to anyone."

**Implementation:**
- Add `users` table to `.avalon.db`:
  ```sql
  CREATE TABLE users (
      id INTEGER PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      display_name TEXT,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      is_active INTEGER DEFAULT 1,
      created_at TEXT NOT NULL,
      last_login TEXT
  );
  ```
- Add `sessions` table:
  ```sql
  CREATE TABLE sessions (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      ip_address TEXT,
      user_agent TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id)
  );
  ```
- On first startup, require creation of an admin account.
- Passwords hashed with **Argon2id** (crate: `argon2`).
- Enforce minimum 8 characters, block top 10,000 breached passwords (use `zxcvbn` or offline HIBP list).

### 1.2 Session Management

- Generate 256-bit random session tokens (crate: `rand`).
- Store token hash (SHA-256) in DB, not the raw token.
- Sessions expire after **8 hours** of inactivity or **24 hours** absolute.
- Bind sessions to IP address; reject if IP changes (optional toggle).
- On logout, invalidate session immediately.

### 1.3 API Protection

- All endpoints (except `/api/health` and `/api/login`) require valid session token in `Authorization: Bearer <token>` header.
- Return `401 Unauthorized` with JSON body: `{"error": "Authentication required"}`.
- Rate-limit login attempts: 5 per minute per IP.

### 1.4 UI Login Flow

- On startup, Electron checks for active session.
- If none, render a login screen before the main app.
- Remember me option: extends session to 7 days (with explicit checkbox).

**Deliverable:** Login screen, account creation, session expiry, logout button.

---

## Phase 2 — Role-Based Access Control (Weeks 2–3)

### 2.1 Roles

| Role | Permissions |
|---|---|
| `admin` | Full access: create agents, manage users, change config, view all audit logs |
| `developer` | Use tools, chat, dispatch agents, view own audit logs |
| `readonly` | View chat history, read files, cannot write or dispatch |

### 2.2 Enforcement

- Add `role` field to `users` table.
- Middleware in Actix-web that checks `req.role` against endpoint allowlist.
- Tool execution: `write_file`, `delete_file`, `dispatch_agent` require `developer` or `admin`.
- Agent registry mutations require `admin`.

### 2.3 Per-User File Limits

- Extend `FileSystemConfig` to include a `user_overrides` map:
  ```json
  {
    "user_overrides": {
      "alice": { "allowed_paths": ["D:/AliceProjects"] },
      "bob": { "allowed_paths": ["D:/BobProjects", "D:/Shared"] }
    }
  }
  ```
- If no override, fall back to global `allowed_paths`.

**Deliverable:** Admin user panel, role assignment, per-user path limits.

---

## Phase 3 — Encryption (Weeks 3–4)

### 3.1 At-Rest Encryption

**SQLite (`avalon.db`):**
- Use **SQLCipher** (AES-256-CBC or AES-256-GCM) via `libsqlite3-sys` with `sqlcipher` feature.
- Key derivation: user's password + salt → PBKDF2-HMAC-SHA256 (100k iterations) → SQLCipher key.
- On first startup, generate a random 256-bit salt stored in `~/.avalon/.db_salt`.
- If user forgets password, data is unrecoverable (by design).

**Config files:**
- Encrypt `.avalon_state.json` and `.avalon_fs.json` with AES-256-GCM.
- Key derived from machine fingerprint + user password (so moving the file to another machine without the password fails).

### 3.2 In-Transit Encryption

**Option A — Minimal (sufficient for single-user desktop):**
- Keep `127.0.0.1:8080` HTTP binding.
- Document that this is acceptable because the attack surface is local-only.
- Add a `--bind` CLI flag so admins can restrict to a specific interface if needed.

**Option B — Enhanced (for multi-user or terminal server deployments):**
- Generate a self-signed TLS certificate on first run.
- Store cert/key in `~/.avalon/certs/`.
- Use `rustls` in Actix-web.
- Pin the certificate fingerprint in the Electron client.
- Admin option to upload a corporate CA-signed cert.

**Recommendation:** Implement Option A now, Option B as a toggle.

**Deliverable:** Encrypted DB, encrypted configs, TLS toggle.

---

## Phase 4 — Enhanced Audit & Logging (Weeks 4–5)

### 4.1 New Audit Events

Add these entry types to the existing hash-chained audit log:

| Event | Actor | Data |
|---|---|---|
| `auth_login` | user | username, success/failure, IP |
| `auth_logout` | user | username, session_id |
| `auth_failure` | system | username, reason, IP, count |
| `session_expired` | system | session_id, reason |
| `account_created` | admin | new_username, role |
| `account_disabled` | admin | username, reason |
| `role_changed` | admin | username, old_role, new_role |
| `config_changed` | admin | key, old_value_hash, new_value_hash |
| `permission_denied` | system | username, tool, reason |
| `agent_dispatched` | user | agent_name, task_hash, dispatch_id |

### 4.2 Log Protection

- Encrypt audit log files with a key stored separately from the logs.
- Use `libsodium` `secretstream` for streaming encryption.
- On Unix, set closed session files to read-only (`0o444`).
- On Windows, restrict ACL to the running user.

### 4.3 Export & Review

- Admin endpoint: `/api/audit/sessions?user=alice&from=2026-04-01&to=2026-04-30`.
- Export to CSV or NDJSON for SIEM ingestion.
- Retention: keep active session in hot storage; archive closed sessions to `logs/audit/YYYY-MM-DD.tar.gz` with manifest.

**Deliverable:** New audit events, encrypted logs, admin query endpoint.

---

## Phase 5 — Software Integrity & Supply Chain (Weeks 5–6)

### 5.1 Dependency Scanning

- Add `cargo audit` check to CI/CD pipeline.
- Fail builds if `Cargo.lock` contains known CVEs.
- Add a `security-audit` GitHub Action that runs weekly.
- Document results in `Docs/SECURITY_AUDIT.md`.

### 5.2 Download Scanning

- Before storing fetched content, pass it through Windows Defender or a minimal ClamAV scan.
- If malware detected, reject the file, log an incident, and alert the user.

### 5.3 Code Signing

- Sign `avalon_backend.exe` and the Electron installer with an **EV Code Signing certificate**.
- Windows SmartScreen will warn users if the binary is unsigned.
- Store the signing key in an HSM or Azure Key Vault (not in the repo).

### 5.4 File Integrity Monitoring (Lightweight)

- On startup, compute SHA-256 of `.avalon.db`, `Cargo.toml`, and critical config files.
- Compare against last known good hash stored in `~/.avalon/.integrity`.
- If mismatch, alert user and require admin override to continue.

**Deliverable:** `cargo audit` CI, download scanning, code signing, integrity check.

---

## Phase 6 — Operational Security (Weeks 6–7)

### 6.1 Secure Defaults

| Setting | Current | Target |
|---|---|---|
| Default policy | deny | deny (keep) |
| Max file size | 10 MB | 10 MB (keep) |
| Web fetch domains | allow github.com | require confirmation for new domains |
| Agent tool whitelist | fetch_url, web_scrape | remove if not needed |
| SSE timeout | none | 5 minutes idle timeout |
| Session timeout | none | 8 hours |

### 6.2 Data Sanitization

- Before any file is written by an agent, strip null bytes and control characters.
- Enforce UTF-8 encoding; reject binary data for text files.
- Validate JSON/XML before storing to prevent parser attacks.

### 6.3 Backup & Recovery

- Add an encrypted export function: `File > Export Vault`.
- Exports a `.avalon-export` file containing encrypted DB + configs + audit logs.
- Require password to decrypt.
- Document recovery procedure in `Docs/RECOVERY.md`.

**Deliverable:** Secure defaults, sanitization pipeline, encrypted export.

---

## Phase 7 — Corporate Distribution Package (Week 8)

### 7.1 Installer

- MSI or NSIS installer for Windows.
- Install to `C:\Program Files\Avalon\` (requires admin).
- Create `%LOCALAPPDATA%\Avalon\` for user data (DB, configs, logs).
- Register with Windows "Add or Remove Programs."
- Option to install as a Windows service (runs at boot, no user session required).

### 7.2 Corporate Policy Support

- Support Group Policy or registry-based configuration:
  - `HKEY_LOCAL_MACHINE\SOFTWARE\Avalon\allowed_paths`
  - `HKEY_LOCAL_MACHINE\SOFTWARE\Avalon\blocked_domains`
  - `HKEY_LOCAL_MACHINE\SOFTWARE\Avalon\require_mfa`
- If registry keys exist, they override user config (admin-enforced).

### 7.3 Telemetry Toggle

- All network calls are opt-in except model inference.
- Settings page shows exactly what data leaves the machine.
- No phone-home for updates without explicit user consent.

### 7.4 Uninstaller

- Remove all files from `%LOCALAPPDATA%\Avalon\`.
- Offer to securely wipe the DB (overwrite + delete).
- Clean up registry entries.

**Deliverable:** MSI installer, Group Policy support, telemetry toggle, clean uninstall.

---

## Summary: What Changes vs. What Doesn't

### What Gets Built (Technical)

| Feature | Effort | Impact |
|---|---|---|
| Local user accounts + Argon2 | 3 days | High |
| Session management + expiry | 2 days | High |
| RBAC (admin/dev/readonly) | 3 days | High |
| SQLCipher DB encryption | 2 days | High |
| Encrypted config files | 1 day | Medium |
| TLS toggle | 2 days | Medium |
| Enhanced audit events | 3 days | High |
| `cargo audit` CI | 1 day | Medium |
| Download malware scanning | 2 days | Medium |
| Code signing | 2 days | Medium |
| Integrity monitoring | 1 day | Low |
| Secure defaults | 2 days | Medium |
| Encrypted export | 2 days | Medium |
| MSI installer | 3 days | Medium |
| Group Policy support | 2 days | Low |
| Telemetry toggle | 1 day | Low |

**Total engineering:** ~6–7 weeks for one developer.

### What Remains as Organizational Gap

These are **not software features** — they are policies the deploying organization must implement:

- User awareness training (AT.2.056–058)
- Personnel screening and termination (PS.3.183–187)
- Physical protection (PE.1.131–136)
- Risk assessment (RA.3.137–141)
- Security assessment / penetration testing (CA.2.142–148)
- Incident response plan and team (IR.2.093–095)
- Configuration management process (CM.2.062–067)
- Media protection procedures (MP.3.120–126)

**Recommendation:** Include a `Docs/CORPORATE_DEPLOYMENT.md` document that lists these gaps and provides templates for the customer to fill in. This turns a "no, we don't do that" into "here's the template you need to complete."

---

## Conclusion

This pragmatic plan makes Avalon **corporate-ready** by addressing the controls that InfoSec teams actually ask about:
1. Who can access it? **→ Authentication + RBAC**
2. Is the data encrypted? **→ SQLCipher + AES-GCM**
3. Can we audit it? **→ Hash-chained logs + export**
4. Is the software trustworthy? **→ Signed binaries + dependency scanning**
5. Can we manage it centrally? **→ Group Policy + MSI installer**

It does not achieve CMMC Level 2 certification. For that, see `Docs/CMMC_L2_ROADMAP.md`.

---

## Document Control

| Version | Date | Author | Changes |
|---|---|---|---|
| 1.0 | 2026-04-29 | Worldsmith | Initial pragmatic hardening plan |

