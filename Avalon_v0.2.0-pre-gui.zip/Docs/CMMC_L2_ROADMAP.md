# Avalon CMMC Level 2 Compliance Roadmap

**Document Status:** Reference / Future Planning
**Last Updated:** 2026-04-29
**Target:** Full CMMC 2.0 Level 2 (NIST SP 800-171 Rev 2 alignment)

---

## Executive Summary

This document is a **reference blueprint** for bringing Avalon to full CMMC Level 2 compliance. It is **not a current work item** — it exists so that if a stakeholder, auditor, or customer requires CUI-handling certification in the future, the technical gap is already mapped.

CMMC Level 2 is an **organizational certification**, not a product stamp. Avalon would need to be one component of a larger System Security Plan (SSP). This document covers only the technical changes to Avalon itself.

---

## Gap Summary Table

| Control Family | Total Controls | Currently Met | Gap | Priority |
|---|---|---|---|---|
| Access Control (AC) | 8 | ~1 | 7 | Critical |
| Awareness & Training (AT) | 3 | 0 | 3 | Organizational |
| Audit & Accountability (AU) | 9 | ~4 | 5 | High |
| Configuration Management (CM) | 8 | ~1 | 7 | Medium |
| Identification & Authentication (IA) | 11 | 0 | 11 | Critical |
| Incident Response (IR) | 3 | 0 | 3 | High |
| Maintenance (MA) | 6 | ~2 | 4 | Low |
| Media Protection (MP) | 8 | ~1 | 7 | Medium |
| Personnel Security (PS) | 5 | 0 | 5 | Organizational |
| Physical Protection (PE) | 6 | 0 | 6 | Organizational |
| Risk Assessment (RA) | 6 | 0 | 6 | Organizational |
| Security Assessment (CA) | 7 | 0 | 7 | Organizational |
| System & Communications Protection (SC) | 24 | ~2 | 22 | Critical |
| System & Information Integrity (SI) | 7 | ~1 | 6 | High |

**Overall:** Avalon currently satisfies roughly **8–12%** of the technical control requirements for CMMC Level 2.

---

## 1. Identification & Authentication (IA)

**Current state:** No authentication. Anonymous access to `127.0.0.1:8080`.

| Control | Requirement | Implementation |
|---|---|---|
| IA.1.076 | Identify system users | Add user identity to every audit log entry |
| IA.2.077 | Unique user IDs | SQLite `users` table with UUID primary keys |
| IA.2.078 | Multifactor authentication (MFA) | TOTP or WebAuthn integration |
| IA.2.079 | Local access authentication | Same auth for localhost as remote |
| IA.2.080 | Password complexity | NIST 800-63B: min 8 chars, block breached passwords |
| IA.2.081 | Password lifetime | 90-day rotation or event-driven change |
| IA.2.082 | Password history | Store last 12 hashes, prevent reuse |
| IA.2.083 | Session lock | Auto-lock after 15 min idle; kill SSE |
| IA.2.084 | Identifier management | Disable inactive accounts after 90 days |
| IA.2.085 | Authenticator management | Centralized credential storage, recovery codes |
| IA.2.086 | Privacy-enhanced auth | Minimize PII collection for user accounts |

**Implementation sketch:**
- Replace open API with JWT sessions (`HttpOnly` cookies + CSRF tokens).
- Add login screen before main UI.
- Store Argon2id password hashes in `.avalon.db`.
- `sessions` table with `expired_at`, `mfa_verified`, `ip_address`, `user_agent`.

---

## 2. Access Control (AC)

**Current state:** File-system limiter provides path bounds, but no identity-based access control.

| Control | Requirement | Implementation |
|---|---|---|
| AC.2.007 | Least privilege | RBAC: `admin`, `developer`, `readonly` |
| AC.2.008 | Separation of duties | Admin cannot be end-user for agent dispatch |
| AC.2.009 | Remote access | Device compliance checks if accessed via VPN/RDP |
| AC.2.010 | Audit access rights | Quarterly review endpoint in admin dashboard |
| AC.2.011 | Account creation | Only admins create accounts; log every creation |
| AC.2.012 | Privileged functions | Re-auth for agent registry mutations |
| AC.2.013 | Privileged accounts | Admin accounts enforce stricter MFA |
| AC.2.014 | Wireless access | Document host wireless controls |

**Implementation sketch:**
- `users` table with `role` column.
- `user_permissions` junction table for tool/path/domain allowlists per user.
- File-system limiter becomes **user-scoped**.

---

## 3. System & Communications Protection (SC)

**Current state:** HTTP only. No TLS. No encryption at rest. No FIPS validation.

| Control | Requirement | Implementation |
|---|---|---|
| SC.1.175 | Boundary protection | Document host firewall rules |
| SC.2.176 | FIPS-validated crypto | Replace `ring` with `aws-lc-rs` (FIPS mode) |
| SC.2.177 | Encrypt CUI at rest | SQLCipher for `.avalon.db`; encrypt audit logs |
| SC.2.178 | Encrypt CUI in transit | TLS 1.3 on Actix-web; pinned certs |
| SC.2.179 | Session authenticity | Signed JWT with HMAC-SHA256; secret rotation |
| SC.2.180 | Mobile code | N/A for desktop app, but document |
| SC.2.181 | Split tunneling | Document host does not route CUI through untrusted tunnels |
| SC.2.182 | Collaborative computing | N/A for single-user desktop |
| SC.2.183 | Information in shared resources | Enforce file-system limiter across all users |
| SC.2.184 | Deny by default / allow by exception | Already implemented for file/network access |
| SC.2.185 | Voice-over-IP | N/A |
| SC.2.186 | Protect CUI in email | N/A |
| SC.2.187 | Prevent CUI exfiltration | Enhanced domain allowlist + DLP-style pattern matching |

**Implementation sketch:**
- SQLCipher integration (AES-256-GCM).
- TLS with `rustls` + `aws-lc-rs`.
- Encrypt `.avalon_state.json` and `.avalon_fs.json` with password-derived key.
- Certificate generation on first run (self-signed or local CA).

---

## 4. Audit & Accountability (AU)

**Current state:** Excellent hash-chained audit trail. Missing centralized logging, integrity monitoring, retention.

| Control | Requirement | Implementation |
|---|---|---|
| AU.1.003 | Audit events | Add: login/logout, failed auth, config changes, agent dispatches |
| AU.2.004 | Audit storage capacity | Alert when audit partition >80% full |
| AU.2.005 | Response to audit processing failures | Stop operations if audit log cannot be written |
| AU.2.006 | Audit review | Admin endpoint to query by user/date/severity |
| AU.2.007 | Audit reduction | Filter noise; keep auths, drop health checks |
| AU.2.008 | Timestamp | NTP-synced timestamps (Windows time service) |
| AU.2.009 | Audit log protection | Append-only, encrypted, write to WORM or SIEM |
| AU.2.010 | Audit log retention | 1-year minimum; automated archiving |
| AU.2.011 | Audit log content | Include: user ID, session ID, tool name, args hash, timestamp |

**Implementation sketch:**
- Add `auth_login`, `auth_failure`, `config_change`, `account_created` entry types.
- Encrypt audit logs with key stored in TPM or separate file.
- Stream to Windows Event Log or syslog for SIEM ingestion.

---

## 5. System & Information Integrity (SI)

**Current state:** No malware scanning. No patch management. No FIM.

| Control | Requirement | Implementation |
|---|---|---|
| SI.1.210 | Flaw remediation | `cargo audit` in CI/CD; block builds with known CVEs |
| SI.1.211 | Malicious code protection | Scan `fetch_url`/`web_scrape` downloads with ClamAV/Defender |
| SI.2.212 | Malicious code protection (updated) | Real-time scan via Windows Defender AMSI |
| SI.2.213 | System monitoring | File integrity monitoring (FIM) for `.avalon.db` and configs |
| SI.2.214 | Flaw remediation (updated) | Automated dependency update alerts |
| SI.2.215 | System monitoring (updated) | Alert on unauthorized config changes |
| SI.2.216 | Software integrity | Code-sign releases with EV certificate |

**Implementation sketch:**
- `cargo audit` check in build pipeline.
- ClamAV integration for downloaded content.
- SHA-256 of `.avalon.db` at session end; verify on startup.
- EV code signing for Windows releases.

---

## 6. Configuration Management (CM)

**Current state:** JSON configs exist but no change control or baseline.

| Control | Requirement | Implementation |
|---|---|---|
| CM.2.054 | Baseline configurations | Define approved config baseline; store hash |
| CM.2.055 | Configuration change control | All config changes require admin approval + logging |
| CM.2.056 | Security settings | Lock down config keys; prevent user override of security params |
| CM.2.057 | Least functionality | Disable unnecessary tools by default; whitelist approach |
| CM.2.058 | Information location | Document where CUI may be stored within Avalon |
| CM.2.059 | System component inventory | SBOM generation via `cargo tree` + npm audit |
| CM.2.060 | System component authenticity | Verify dependency checksums in `Cargo.lock` |
| CM.2.061 | Developer configuration management | Separate dev/test/prod database instances |

---

## 7. Incident Response (IR)

**Current state:** No incident response capability.

| Control | Requirement | Implementation |
|---|---|---|
| IR.2.096 | Incident response plan | Document IR plan; add `/api/incident/report` endpoint |
| IR.2.097 | Incident reporting | Report to US-CERT within 72 hours of CUI breach |
| IR.2.098 | Incident testing | Annual tabletop exercise template |
| IR.2.099 | Incident handling | Automated alert on: >5 failed logins, unauthorized path access |

---

## 8. Media Protection (MP)

**Current state:** No media encryption or sanitization.

| Control | Requirement | Implementation |
|---|---|---|
| MP.2.119 | Media protection | Encrypt backups of `.avalon.db` before external copy |
| MP.2.120 | Media sanitization | Secure wipe deleted files (overwrite 3x before unlink) |
| MP.2.121 | Media disposal | Cryptographic erasure of DB keys for disposal |
| MP.2.122 | Media markings | Label exported audit logs and models with CUI markings |
| MP.2.123 | Media transport | Encrypt any transport of DB files |
| MP.2.124 | Media storage | Store encrypted backups offline |
| MP.2.125 | Media access | Restrict backup restore to admin role |
| MP.2.126 | Media accountability | Inventory of all backup media |

---

## Implementation Phases (Full L2)

### Phase 1 — Identity & Crypto Foundation (8–10 weeks)
1. User accounts + Argon2id passwords
2. TOTP MFA
3. JWT session management
4. TLS 1.3
5. SQLCipher `.avalon.db`
6. Encrypted config files

### Phase 2 — Access Control & Audit (6–8 weeks)
7. RBAC with per-user limits
8. Admin dashboard
9. Login/auth events in audit trail
10. Audit log encryption + Windows Event Log streaming
11. Automated audit archiving

### Phase 3 — Integrity & Protection (4–6 weeks)
12. `cargo audit` CI integration
13. ClamAV/Defender download scanning
14. File integrity monitoring
15. EV code signing

### Phase 4 — Documentation & Process (4–6 weeks)
16. System Security Plan (SSP)
17. Incident Response Plan
18. Configuration baseline
19. Personnel screening procedures
20. C3PAO audit preparation

**Total estimated effort:** 22–30 weeks engineering + 4–6 weeks documentation.
**Estimated audit cost:** $15,000–$50,000+ (C3PAO dependent).

---

## Pragmatic Alternative

If full L2 is not immediately required, see `PRAGMATIC_HARDENING.md` for a defensible, corporate-ready hardening plan that achieves ~60% of L2 security value at ~15% of the cost.

---

## Document Control

| Version | Date | Author | Changes |
|---|---|---|---|
| 1.0 | 2026-04-29 | Worldsmith | Initial gap analysis and roadmap |

