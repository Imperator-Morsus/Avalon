use crate::db::{VaultDb, VaultItem, VaultRelationship, VaultNotification};
use sha2::{Digest, Sha256};
use std::path::Path;
use std::sync::{Arc, Mutex};
use image::GenericImageView;

// ═════════════════════════════════════════════════════════════════════════════
// The Vault Service (Phase 1 — Unified)
// Handles ingestion, search, relationships, embeddings, contradictions, and notifications.
// ═════════════════════════════════════════════════════════════════════════════

pub struct VaultService {
    db: Arc<Mutex<VaultDb>>,
}

impl VaultService {
    pub fn new(db: Arc<Mutex<VaultDb>>) -> Self {
        Self { db }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Ingestion
    // ═════════════════════════════════════════════════════════════════════════

    /// Ingest a document or image from disk into the vault.
    /// Returns the item ID if successful.
    pub fn ingest_file(
        &self,
        path: &Path,
        title: Option<&str>,
        content_type_hint: Option<&str>,
    ) -> Result<i64, String> {
        let bytes = match std::fs::read(path) {
            Ok(b) => b,
            Err(e) => return Err(format!("Failed to read file: {}", e)),
        };

        let hash = format!("{:x}", Sha256::digest(&bytes));

        // Check if already ingested (exact hash match)
        let already_exists = {
            let db = self.db.lock().unwrap();
            db.item_exists_by_hash(&hash).map_err(|e| e.to_string())?
        };
        if already_exists {
            return Err("Item already exists in vault".to_string());
        }

        let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("").to_lowercase();
        let source_path = path.to_string_lossy().to_string();
        let now = chrono::Utc::now().to_rfc3339();

        // Check if source_path already exists (re-ingestion)
        let existing_item = {
            let db = self.db.lock().unwrap();
            db.find_item_by_source_path(&source_path).map_err(|e| e.to_string())?
        };

        // Determine content type
        let content_type = content_type_hint.unwrap_or_else(|| {
            match ext.as_str() {
                "pdf" => "pdf",
                "md" => "markdown",
                "rs" | "js" | "ts" | "py" | "go" | "java" | "c" | "cpp" | "h" | "hpp" | "cs" | "sh" | "bat" | "ps1" => "code",
                "html" | "htm" => "html",
                "txt" | "log" => "text",
                "jpg" | "jpeg" => "image",
                "png" => "image",
                "gif" => "image",
                "webp" => "image",
                "bmp" => "image",
                "svg" => "image",
                "ico" => "image",
                "mp4" | "webm" | "avi" | "mov" => "video",
                "mp3" | "wav" | "ogg" | "flac" => "audio",
                _ => "text",
            }
        });

        let (content, format, width, height, duration) = match content_type {
            "pdf" => (extract_pdf_text(&bytes)?, Some(ext.clone()), None, None, None),
            "html" => {
                let raw = String::from_utf8_lossy(&bytes).to_string();
                (sanitize_html_text(&raw), Some(ext.clone()), None, None, None)
            }
            "image" => {
                let (w, h) = detect_image_dimensions(path);
                (String::new(), Some(ext.clone()), w, h, None)
            }
            "video" | "audio" => {
                // Placeholder: real duration detection requires ffprobe or similar
                (String::new(), Some(ext.clone()), None, None, None)
            }
            _ => {
                let raw = String::from_utf8_lossy(&bytes).to_string();
                (sanitize_text(&raw), None, None, None, None)
            }
        };

        if content_type != "image" && content_type != "video" && content_type != "audio" && content.is_empty() {
            return Err("Extracted content is empty".to_string());
        }

        let title = title.map(|s| s.to_string()).or_else(|| {
            path.file_stem().map(|s| s.to_string_lossy().to_string())
        });

        let db = self.db.lock().unwrap();
        let id = db.insert_item(
            &source_path,
            title.as_deref(),
            None, // description
            &content,
            content_type,
            format.as_deref(),
            Some(bytes.len()),
            width,
            height,
            duration,
            &now,
            &hash,
            None,
        ).map_err(|e| e.to_string())?;

        // If this is a re-ingestion, link versions
        if let Some(old) = existing_item {
            let _ = db.update_item_status(old.id, "archived");
            let _ = db.insert_relationship(
                id, old.id, "newer_version", 1.0, None, &now
            );
            let _ = db.insert_relationship(
                old.id, id, "older_version", 1.0, None, &now
            );
        }

        Ok(id)
    }

    /// Ingest text content directly (for fetched/scraped content without a file).
    pub fn ingest_text(
        &self,
        source_path: &str,
        title: Option<&str>,
        content: &str,
        content_type: &str,
    ) -> Result<i64, String> {
        let hash = format!("{:x}", Sha256::digest(content.as_bytes()));

        let already_exists = {
            let db = self.db.lock().unwrap();
            db.item_exists_by_hash(&hash).map_err(|e| e.to_string())?
        };
        if already_exists {
            return Err("Item already exists in vault".to_string());
        }

        let sanitized = sanitize_text(content);
        if sanitized.is_empty() {
            return Err("Content is empty after sanitization".to_string());
        }

        let now = chrono::Utc::now().to_rfc3339();
        let db = self.db.lock().unwrap();
        let id = db.insert_item(
            source_path,
            title,
            None,
            &sanitized,
            content_type,
            None,
            Some(content.len()),
            None, None, None,
            &now,
            &hash,
            None,
        ).map_err(|e| e.to_string())?;

        Ok(id)
    }

    /// Ingest an image file into the vault (replaces VisionService::ingest_image).
    pub fn ingest_image(
        &self,
        path: &Path,
        description: Option<&str>,
        tags: Option<&str>,
    ) -> Result<i64, String> {
        let bytes = match std::fs::read(path) {
            Ok(b) => b,
            Err(e) => return Err(format!("Failed to read image: {}", e)),
        };

        let hash = format!("{:x}", Sha256::digest(&bytes));

        let already_exists = {
            let db = self.db.lock().unwrap();
            db.item_exists_by_hash(&hash).map_err(|e| e.to_string())?
        };
        if already_exists {
            return Err("Image already exists in vault".to_string());
        }

        let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("").to_lowercase();
        let source_path = path.to_string_lossy().to_string();
        let (width, height) = detect_image_dimensions(path);
        let now = chrono::Utc::now().to_rfc3339();

        let meta = if let Some(t) = tags {
            Some(format!("{{\"confirmed\":0,\"tags\":\"{}\"}}", t))
        } else {
            Some("{\"confirmed\":0}".to_string())
        };

        let db = self.db.lock().unwrap();
        let id = db.insert_item(
            &source_path,
            description,
            description,
            "",
            "image",
            Some(&ext),
            Some(bytes.len()),
            width,
            height,
            None,
            &now,
            &hash,
            meta.as_deref(),
        ).map_err(|e| e.to_string())?;

        Ok(id)
    }

    /// Confirm an image description (replaces VisionService::confirm_image_description).
    pub fn confirm_image_description(
        &self,
        id: i64,
        description: &str,
        tags: &str,
    ) -> Result<(), String> {
        let db = self.db.lock().unwrap();
        let item = db.get_item(id).map_err(|e| e.to_string())?;
        if item.is_none() {
            return Err("Image not found".to_string());
        }
        // Update metadata to confirmed
        let meta = format!("{{\"confirmed\":1,\"tags\":\"{}\"}}", tags);
        db.conn.execute(
            "UPDATE vault_items SET description = ?1, metadata = ?2 WHERE id = ?3",
            (description, meta, id),
        ).map_err(|e| e.to_string())?;
        Ok(())
    }

    /// Batch ingest all files from a directory tree into the vault.
    pub fn sync_directory(
        &self,
        path: &Path,
    ) -> Result<(usize, usize, usize), String> {
        let mut ingested = 0;
        let mut skipped = 0;
        let mut errors = 0;

        for entry in walkdir::WalkDir::new(path) {
            let entry = match entry {
                Ok(e) => e,
                Err(_) => { errors += 1; continue; }
            };
            if !entry.file_type().is_file() { continue; }

            let p = entry.path();
            let ext = p.extension().and_then(|e| e.to_str()).unwrap_or("").to_lowercase();
            let is_image = matches!(ext.as_str(), "jpg"|"jpeg"|"png"|"gif"|"webp"|"bmp"|"svg"|"ico");

            let result = if is_image {
                self.ingest_image(p, None, None)
            } else {
                self.ingest_file(p, None, None)
            };

            match result {
                Ok(_) => ingested += 1,
                Err(e) if e.contains("already exists") => skipped += 1,
                Err(_) => errors += 1,
            }
        }

        Ok((ingested, skipped, errors))
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Search
    // ═════════════════════════════════════════════════════════════════════════

    pub fn search(&self, query: &str, limit: usize
    ) -> Result<Vec<VaultItem>, String> {
        let db = self.db.lock().unwrap();
        db.search_items(query, limit).map_err(|e| e.to_string())
    }

    pub fn get(&self, id: i64) -> Result<Option<VaultItem>, String> {
        let db = self.db.lock().unwrap();
        db.get_item(id).map_err(|e| e.to_string())
    }

    pub fn list_all(&self) -> Result<Vec<VaultItem>, String> {
        let db = self.db.lock().unwrap();
        db.list_all_items().map_err(|e| e.to_string())
    }

    pub fn list_by_type(&self, content_type: &str
    ) -> Result<Vec<VaultItem>, String> {
        let db = self.db.lock().unwrap();
        db.list_items_by_type(content_type).map_err(|e| e.to_string())
    }

    pub fn delete(&self, id: i64) -> Result<bool, String> {
        let db = self.db.lock().unwrap();
        db.delete_item(id).map_err(|e| e.to_string())
    }

    /// Semantic search over vault embeddings.
    /// Returns items sorted by cosine similarity, highest first.
    pub fn semantic_search(
        &self,
        query_embedding: &[f32],
        limit: usize,
    ) -> Result<Vec<(VaultItem, f64)>, String> {
        let db = self.db.lock().unwrap();
        let all = db.all_embeddings().map_err(|e| e.to_string())?;

        let mut scored: Vec<(i64, f64)> = Vec::with_capacity(all.len());
        for emb in all {
            let vec = crate::embeddings::bytes_to_embedding(&emb.embedding);
            if vec.len() == query_embedding.len() {
                let sim = crate::embeddings::cosine_similarity(query_embedding, &vec);
                scored.push((emb.item_id, sim));
            }
        }

        scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        scored.truncate(limit);

        let mut results = Vec::with_capacity(scored.len());
        for (item_id, sim) in scored {
            if let Ok(Some(item)) = db.get_item(item_id) {
                results.push((item, sim));
            }
        }
        Ok(results)
    }

    /// Store an embedding for a vault item.
    pub fn store_embedding(
        &self,
        item_id: i64,
        embedding: &[f32],
        model: &str,
    ) -> Result<(), String> {
        let db = self.db.lock().unwrap();
        let bytes = crate::embeddings::embedding_to_bytes(embedding);
        let now = chrono::Utc::now().to_rfc3339();
        db.insert_embedding(item_id, &bytes, model, &now)
            .map_err(|e| e.to_string())?;
        db.update_item_embedding_synced(item_id, true)
            .map_err(|e| e.to_string())?;
        Ok(())
    }

    pub fn item_exists_by_hash(&self, hash: &str) -> Result<bool, String> {
        let db = self.db.lock().unwrap();
        db.item_exists_by_hash(hash).map_err(|e| e.to_string())
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Relationships
    // ═════════════════════════════════════════════════════════════════════════

    pub fn link_items(
        &self,
        source_id: i64,
        target_id: i64,
        relation_type: &str,
        confidence: f64,
        reason: Option<&str>,
    ) -> Result<i64, String> {
        let now = chrono::Utc::now().to_rfc3339();
        let db = self.db.lock().unwrap();
        db.insert_relationship(source_id, target_id, relation_type, confidence, reason, &now)
            .map_err(|e| e.to_string())
    }

    pub fn get_related_items(
        &self,
        id: i64,
    ) -> Result<Vec<VaultRelationship>, String> {
        let db = self.db.lock().unwrap();
        db.get_relationships_for_item(id, None).map_err(|e| e.to_string())
    }

    pub fn get_contradictions(
        &self,
        id: i64,
    ) -> Result<Vec<VaultRelationship>, String> {
        let db = self.db.lock().unwrap();
        db.get_relationships_for_item(id, Some("contradicts")).map_err(|e| e.to_string())
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Contradictions
    // ═════════════════════════════════════════════════════════════════════════

    /// Flag a contradiction between two items and create a notification.
    pub fn flag_contradiction(
        &self,
        newer_id: i64,
        older_id: i64,
        reason: &str,
        confidence: f64,
    ) -> Result<(), String> {
        let now = chrono::Utc::now().to_rfc3339();
        let db = self.db.lock().unwrap();

        db.insert_relationship(newer_id, older_id, "contradicts", confidence, Some(reason), &now)
            .map_err(|e| e.to_string())?;

        db.update_item_contradiction(newer_id, true, Some(reason))
            .map_err(|e| e.to_string())?;
        db.update_item_contradiction(older_id, true, Some(reason))
            .map_err(|e| e.to_string())?;

        let msg = format!("Contradiction detected: newer item {} contradicts older item {}. Reason: {}", newer_id, older_id, reason);
        db.insert_notification(newer_id, "contradiction", &msg, &now)
            .map_err(|e| e.to_string())?;
        db.insert_notification(older_id, "contradiction", &msg, &now)
            .map_err(|e| e.to_string())?;

        Ok(())
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Notifications
    // ═════════════════════════════════════════════════════════════════════════

    pub fn get_unread_notifications(
        &self,
        limit: usize,
    ) -> Result<Vec<VaultNotification>, String> {
        let db = self.db.lock().unwrap();
        db.get_unread_notifications(limit).map_err(|e| e.to_string())
    }

    pub fn mark_notification_read(&self,
        id: i64,
    ) -> Result<bool, String> {
        let db = self.db.lock().unwrap();
        db.mark_notification_read(id).map_err(|e| e.to_string())
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Embeddings (Phase 2 hooks)
    // ═════════════════════════════════════════════════════════════════════════

    pub fn queue_for_embedding(&self, id: i64) -> Result<(), String> {
        let db = self.db.lock().unwrap();
        db.update_item_embedding_synced(id, false).map_err(|e| e.to_string())
    }

    pub fn get_items_needing_embeddings(
        &self, limit: usize
    ) -> Result<Vec<VaultItem>, String> {
        let db = self.db.lock().unwrap();
        db.list_items_needing_embeddings(limit).map_err(|e| e.to_string())
    }

    /// Build the text payload for embedding generation from a vault item.
    /// Combines title, description, and content with appropriate weighting.
    pub fn embedding_text_for_item(&self,
        item: &VaultItem,
    ) -> String {
        let mut parts = Vec::new();
        if let Some(ref title) = item.title {
            if !title.is_empty() {
                parts.push(title.clone());
            }
        }
        if let Some(ref desc) = item.description {
            if !desc.is_empty() {
                parts.push(desc.clone());
            }
        }
        if !item.content.is_empty() {
            let content = item.content.chars().take(2000).collect::<String>();
            parts.push(content);
        }
        parts.join("\n\n")
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Graph builder (for mindmap)
    // ═════════════════════════════════════════════════════════════════════════

    pub fn build_directory_graph(
        &self,
    ) -> Result<crate::mindmap::MindMap, String> {
        let items = self.list_all()?;
        let mut mm = crate::mindmap::MindMapService::new();
        let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();

        // Root node
        mm.add_node("vault:root", "The Vault".to_string(), "root");
        seen.insert("vault:root".to_string());

        for item in &items {
            let path = std::path::Path::new(&item.source_path);
            let mut current = "vault:root".to_string();

            // Build directory nodes from path ancestors
            if let Some(parent) = path.parent() {
                for component in parent.components() {
                    let comp_str = component.as_os_str().to_string_lossy().to_string();
                    let node_id = format!("dir:{}", comp_str);
                    if seen.insert(node_id.clone()) {
                        mm.add_node(&node_id, comp_str.clone(), "dir");
                    }
                    mm.add_edge(&current, &node_id, "contains");
                    current = node_id;
                }
            }

            // Add item node
            let node_type = if item.content_type == "image" { "image" } else { "file" };
            let label = item.title.clone().unwrap_or_else(|| {
                path.file_name()
                    .map(|n| n.to_string_lossy().to_string())
                    .unwrap_or_else(|| format!("item_{}", item.id))
            });

            let mut meta = std::collections::HashMap::new();
            meta.insert("item_id".to_string(), item.id.to_string());
            meta.insert("content_type".to_string(), item.content_type.clone());
            if item.has_contradictions {
                meta.insert("warning".to_string(), "contradiction".to_string());
            }

            mm.add_node_with_metadata(&item.source_path, label.clone(), node_type, meta
            );
            mm.add_edge(&current, &item.source_path, "contains");
        }

        // Add relationship edges
        for item in &items {
            let rels = self.get_related_items(item.id)?;
            for rel in rels {
                let target = self.get(rel.target_id)?;
                if let Some(t) = target {
                    mm.add_edge(
                        &item.source_path,
                        &t.source_path,
                        &rel.relation_type,
                    );
                }
            }
        }

        Ok(mm.graph().clone())
    }
}

// ═════════════════════════════════════════════════════════════════════════════
// Image detection helpers
// ═════════════════════════════════════════════════════════════════════════════

fn detect_image_dimensions(path: &Path) -> (Option<i64>, Option<i64>) {
    if let Ok(reader) = image::ImageReader::open(path) {
        if let Ok(img) = reader.decode() {
            let (w, h) = img.dimensions();
            return (Some(w as i64), Some(h as i64));
        }
    }
    (None, None)
}

// ═════════════════════════════════════════════════════════════════════════════
// Content extraction
// ═════════════════════════════════════════════════════════════════════════════

fn extract_pdf_text(bytes: &[u8]) -> Result<String, String> {
    use lopdf::Document;
    use std::io::Cursor;

    let doc = Document::load_from(Cursor::new(bytes))
        .map_err(|e| format!("PDF parse error: {}", e))?;

    let mut text = String::new();
    for (page_num, _page_id) in doc.get_pages() {
        if let Ok(page_text) = doc.extract_text(&[page_num]) {
            text.push_str(&page_text);
            text.push('\n');
        }
    }

    if text.is_empty() {
        return Err("PDF contains no extractable text".to_string());
    }

    Ok(sanitize_text(&text))
}

// ═════════════════════════════════════════════════════════════════════════════
// Content sanitization
// ═════════════════════════════════════════════════════════════════════════════

fn sanitize_text(input: &str) -> String {
    let mut output = String::with_capacity(input.len());
    for ch in input.chars() {
        match ch {
            '\0' => continue,
            '\u{0001}'..='\u{0008}' | '\u{000b}'..='\u{000c}' | '\u{000e}'..='\u{001f}' => continue,
            _ => output.push(ch),
        }
    }
    output.split_whitespace().collect::<Vec<_>>().join(" ")
}

fn sanitize_html_text(input: &str) -> String {
    let tag_re = regex::Regex::new(r"<[^>]*>").unwrap();
    let stripped = tag_re.replace_all(input, " ");
    let mut text = stripped.to_string();
    text = text.replace("&amp;", "&");
    text = text.replace("&lt;", "<");
    text = text.replace("&gt;", ">");
    text = text.replace("&quot;", "\"");
    text = text.replace("&apos;", "'");
    text = text.replace("&nbsp;", " ");
    sanitize_text(&text)
}
