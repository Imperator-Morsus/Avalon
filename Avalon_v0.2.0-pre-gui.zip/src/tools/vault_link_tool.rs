use serde_json::json;
use crate::tools::{Tool, ToolContext};
use crate::vault::VaultService;
use std::sync::{Arc, Mutex};

// ═════════════════════════════════════════════════════════════════════════════
// vault_link_items Tool
// Creates a relationship (graph edge) between two vault items.
// ═════════════════════════════════════════════════════════════════════════════

pub struct VaultLinkTool {
    vault: Arc<Mutex<VaultService>>,
}

impl VaultLinkTool {
    pub fn new(vault: Arc<Mutex<VaultService>>) -> Self {
        Self { vault }
    }
}

#[async_trait::async_trait]
impl Tool for VaultLinkTool {
    fn name(&self) -> &str {
        "vault_link_items"
    }

    fn description(&self) -> &str {
        "Create a relationship between two vault items. Input: {\"source_id\": 1, \"target_id\": 2, \"relation_type\": \"relates_to\", \"confidence\": 1.0, \"reason\": \"optional\"}"
    }

    fn is_core(&self) -> bool {
        false
    }

    async fn execute(
        &self,
        input: serde_json::Value,
        _ctx: &ToolContext<'_>,
    ) -> Result<serde_json::Value, String> {
        let source_id = input.get("source_id")
            .and_then(|v| v.as_i64())
            .ok_or("Missing 'source_id' argument.")?;
        let target_id = input.get("target_id")
            .and_then(|v| v.as_i64())
            .ok_or("Missing 'target_id' argument.")?;
        let relation_type = input.get("relation_type")
            .and_then(|v| v.as_str())
            .unwrap_or("relates_to");
        let confidence = input.get("confidence")
            .and_then(|v| v.as_f64())
            .unwrap_or(1.0);
        let reason = input.get("reason").and_then(|v| v.as_str());

        let id = self.vault.lock().unwrap().link_items(
            source_id, target_id, relation_type, confidence, reason
        ).map_err(|e| e.to_string())?;

        Ok(json!({
            "ok": true,
            "relationship_id": id,
            "source_id": source_id,
            "target_id": target_id,
            "relation_type": relation_type,
        }))
    }
}
